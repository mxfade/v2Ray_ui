---
name: Feature request
about: Suggest an idea for this project
title: "[feature]"
labels: ''
assignees: ''

---

**Describe the features you want**


**Why do you need it**


**other description**
